# vw_decoder
Easy decode your Volkswagen car equipment.<br />
This web based app allow check what factory instaled in your volkswagen car in 3 simple steps;

1.Wrote codes (max 50 codes)<br/>
2.Click "check" button<br />
3.Look on table and see what you got<br />
<br />
You can look this app on my website, or dowload to your computer and start "localhost" (via xampp or something else).
