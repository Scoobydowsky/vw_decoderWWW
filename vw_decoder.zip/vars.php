<?php
//data in copyright
$now = new DateTime();
$year = $now->format("Y");
//var to codes
$code_qty = 10;
 ?>
